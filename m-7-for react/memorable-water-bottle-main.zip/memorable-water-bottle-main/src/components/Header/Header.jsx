

const Header = () => {
    return (
        <div>
            <h2>Memorable Water Bottle</h2>
        </div>
    );
};

export default Header;