### Task-4

What will be the result of the following codes:

**var a = isNaN(‘11’);**

**var a = isNaN(2-10);**

Explain your answers.
