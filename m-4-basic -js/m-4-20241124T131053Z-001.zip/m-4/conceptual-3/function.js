function add(a, b){
    const sum=a +b;
    return sum;
}
const result=add(20, 10);

console.log(result);