// const h2 = document.getElementById("parent-one");
// console.log(h2.children);
// h2.style.color = "red";
// h2.style.fontSize = "50px";
// console.log(h2);
// h2.innerText = "Something NEw";

// const alltags = document.getElementsByClassName("item");
// // console.log(alltags);

// for (let item of alltags) {
//   //   console.log(item);
//   item.style.color = "green";
//   //   item.style.backgroundColor = "green";
// }

// const myTags = document.getElementsByTagName("li");
// // console.log(myTags);

// for (let i = 0; i < myTags.length; i++) {
//   //   console.log(myTags[i]);
//   let element = myTags[i];
//   element.style.color = "blue";
// }

// const h1 = document.querySelector("#parent-one");
// console.log(h1);

// const li = document.querySelectorAll(".item");
// console.log(li);

// for (let item of li) {
//   //   console.log(item);
//   item.style.color = "green";
// }

// const parent = document.querySelector(".grandparent");
// const children = parent.children;

// const gp = document.querySelector(".grandparent");
// const children = gp.querySelectorAll(".item");
// console.log(children);

// const children = document.querySelector(".item");
// const parent = children.parentElement;
// console.log(parent);

// ch to gp

// const children = document.querySelector(".item");
// const gp = children.closest(".grandparent");
// console.log(gp);

// baba and chacha

// const parent1 = document.getElementById("parent-one");
// const chacha = parent1.nextElementSibling;
// console.log(chacha);

// const chachac = document.getElementById("parent-two");
// console.log(chachac.previousElementSibling);

// const h3 = document.createElement("h1");
// h3.innerText = "made by js";

// const container = document.querySelector(".grandparent");

// const div = document.createElement("div");
// div.innerHTML = `
//     <h1>Hello</h1>
//     <h3>Hello</h3>
// `;
// div.setAttribute("id", "new-id");
// div.setAttribute("title", "my-title");

// div.removeAttribute("id");

// div.className = "common-class";
// div.classList.add("common-class");

// container.appendChild(div);
// let h1 = document.getElementById("parent-one");

// container.insertBefore(div, h1);

// console.log(container);

// console.log(h3);

// document.getElementById("remove-item").remove();

// const ul = document.getElementById("remove-item");
// const li = document.getElementById("first-item");

// ul.children[0].removeChild(1);
// console.log(ul.children[0].removeChild());
// ul.removeChild();
