/// SESSION PLAN
// Talk about DOM
// Read DOM Elements from `Read` section
// Show parent child relationship


// Go To Project 1 -------------------
// Grab images using document.getElementsByTagName("img")
// Grab all cards using document.getElementsByClassName("card")
// Remove Confusion about ArrayLikeObject and Singular DOM Element
// Change DaiyUI theme using getAttribute() and setAttribute() functions. Button Toggling

// Interview Question: Why HTML is not a Programming Language ?

// Before Going to Project 2 ----------
// Talk about Event Listener using Project 1
// Talk about Styling using JS

// At the beginning of the Project 3 ---
// Talk about Differences between HTMLCollection and NodeList

// Make sure teach data-attribute in Project 5 [Expense calculation]

// This session will ensure ===========
// Updating Style: Create a NavBar with Active Status
// Prevent selecting same thing twice.
// Limited selection of things.
// Apply something Only Once like - Discount Coupon
// Includes disabling button